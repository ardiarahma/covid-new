<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ComCode extends Model
{
    protected $table = 'com_code';
}
