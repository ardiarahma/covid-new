<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HasilSkor extends Model
{
    //
}
